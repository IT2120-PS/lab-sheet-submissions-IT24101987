setwd("C:\\Users\\it24101987\\Desktop\\IT24101987")

#import
branch_data<-read.csv("Exercise.txt",header =TRUE )

#check data
head(branch_data)

#2
str(branch_data)
#get a summary of data
summary(branch_data)

#boxplot for sales
boxplot(branch_data$Sales_X1,
         outline = TRUE,
          outpch=8,
          horizontal = TRUE,
           main="sales ditribution")

#4
summary(branch_data$Advertising)
IQR_advertising<-IQR(branch_data$Advertising)
IQR_advertising#print 

#5
# Function to find outliers based on IQR method
find_outliers <- function(years) {
  # Calculate the 1st and 3rd quartile
  Q1 <- quantile(years, 0.25)
  Q3 <- quantile(years, 0.75)
  
  # Calculate the IQR
  IQR <- Q3 - Q1
  
  # Calculate the lower and upper bounds for outliers
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  
  # Find the outliers
  outliers <- years[years < lower_bound | years > upper_bound]
  
  # Sort outliers for clarity
  outliers <- sort(outliers)
  
  # Print the results
  print(paste("Upper Bound: ", upper_bound))
  print(paste("Lower Bound: ", lower_bound))
  print(paste("IQR: ", IQR))
  print(paste("Outliers: ", paste(outliers, collapse = ", ")))
}

find_outliers(branch_data$Years)


